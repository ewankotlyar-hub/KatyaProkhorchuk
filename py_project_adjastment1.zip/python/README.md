# Менеджер файловой системы (CLI)

Консольная утилита для работы с файлами и папками на Python.

## Установка

Для работы необходим Python 3.10+. Дополнительные зависимости не требуются.

```bash
git clone <url-репозитория>
cd coursework/python
```

## Запуск

```bash
python cli.py <команда> [аргументы]
```

## Команды

| Команда | Описание | Пример |
|---------|----------|--------|
| `copy <файл> [назначение]` | Копировать файл (по умолчанию: текущая папка) | `python cli.py copy report.pdf ./backup` |
| `delete <путь>` | Удалить файл или папку (рекурсивно) | `python cli.py delete old_folder` |
| `count <папка>` | Подсчитать все файлы в папке (включая вложенные) | `python cli.py count ./src` |
| `find <папка> <шаблон>` | Найти файлы по регулярному выражению | `python cli.py find ./src "\.py$"` |
| `rename_date <путь>` | Добавить дату создания к имени файла(ов) | `python cli.py rename_date photo.jpg` |

### Флаги

- `rename_date --recursive` — обработать все уровни вложенности (только для папок)

## Структура проекта

```
python/
├── cli.py                  # Точка входа CLI
├── filemanager_test.py     # Тесты
├── README.md
└── filemanager/            # Пакет с основным функционалом
    ├── __init__.py
    ├── copy.py             # Копирование файлов
    ├── count.py            # Подсчёт файлов
    ├── delete.py           # Удаление файлов и папок
    ├── find.py             # Поиск файлов по шаблону
    └── rename.py           # Переименование с датой создания
```

## Запуск тестов

```bash
python -m pytest filemanager_test.py -v
```

Или через unittest:

```bash
python -m unittest filemanager_test -v
```

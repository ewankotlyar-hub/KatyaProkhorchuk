"""
Менеджер файловой системы (CLI)
Использование: python cli.py <команда> [аргументы]

Команды:
  copy <файл> [назначение]      Копировать файл (по умолчанию: текущая папка)
  delete <путь>                 Удалить файл или папку
  count <папка>                 Подсчитать все файлы в папке (включая вложенные)
  find <папка> <шаблон>         Найти файлы по регулярному выражению (включая вложенные)
  rename_date <путь>            Добавить дату создания к имени файла(ов)
                                --recursive   Обработать все уровни вложенности

Запуск тестов:
  python -m pytest filemanager_test.py
"""

import argparse
import logging

from filemanager import copy_file, delete_path, count_files, find_files, rename_with_date

# ---------------------------------------------------------------------------
# Настройка логирования
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="[%(levelname)s] %(message)s",
)


# ---------------------------------------------------------------------------
# CLI — разбор аргументов командной строки
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    """Создать и вернуть парсер аргументов командной строки."""
    parser = argparse.ArgumentParser(
        prog="cli.py",
        description="Простой менеджер файловой системы.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    sub = parser.add_subparsers(dest="command", metavar="команда")
    sub.required = True

    # --- copy: копирование файла ---
    p_copy = sub.add_parser("copy", help="Копировать файл в указанное место")
    p_copy.add_argument("file", help="Путь к исходному файлу")
    p_copy.add_argument("dest", nargs="?", default=".", help="Путь назначения (по умолчанию: .)")

    # --- delete: удаление файла или папки ---
    p_del = sub.add_parser("delete", help="Удалить файл или папку")
    p_del.add_argument("path", help="Путь к файлу или папке")

    # --- count: подсчёт файлов ---
    p_count = sub.add_parser("count", help="Подсчитать файлы в папке (включая вложенные)")
    p_count.add_argument("folder", help="Целевая папка")

    # --- find: поиск файлов по шаблону ---
    p_find = sub.add_parser("find", help="Найти файлы по регулярному выражению")
    p_find.add_argument("folder", help="Целевая папка")
    p_find.add_argument("pattern", help="Регулярное выражение для имён файлов")

    # --- rename_date: добавить дату к имени ---
    p_rd = sub.add_parser(
        "rename_date",
        help="Добавить дату создания к имени файла(ов)",
    )
    p_rd.add_argument("path", help="Путь к файлу или папке")
    p_rd.add_argument(
        "--recursive",
        action="store_true",
        help="Обработать все уровни вложенности (только для папок)",
    )

    return parser


def run_cli(args: list[str] | None = None) -> None:
    """Разобрать аргументы и вызвать соответствующую функцию."""
    parser = build_parser()
    ns = parser.parse_args(args)

    if ns.command == "copy":
        result = copy_file(ns.file, ns.dest)
        print(f"Файл успешно скопирован: {result}")

    elif ns.command == "delete":
        delete_path(ns.path)
        print(f"Успешно удалено: {ns.path}")

    elif ns.command == "count":
        n = count_files(ns.folder)
        print(f"Количество файлов в папке: {n}")

    elif ns.command == "find":
        results = find_files(ns.folder, ns.pattern)
        if results:
            print(f"Найдено файлов: {len(results)}")
            for r in results:
                print(f"  {r}")
        else:
            print("Файлы по заданному шаблону не найдены.")

    elif ns.command == "rename_date":
        renamed = rename_with_date(ns.path, recursive=ns.recursive)
        print(f"Переименовано файлов: {len(renamed)}")


# ---------------------------------------------------------------------------
# Точка входа
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    run_cli()
